#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

char ozan[50];
char calgi[50];

// Genel
int para = 10, seviye = 0, tecrube = 0;
// Temel nitelikler [0-100]
int can = 10, tokluk = 5, uyku = 5, hijyen = 5;
// Bizim eklediğimiz temel nitelikler
int siviSeviyesi = 5, huzur = 5, odaklanma = 5;
// Beceriler [0-25]
int guc = 3, ceviklik = 3, dayaniklilik = 3, karizma = 3, toplayicilik = 3;

int beceriSecimi = 0;
int beceriyeAktarilacakPuan = 0;
int beceriPuani = 5;
int merhemNum = 0;
int kazanilacakTecrube = 0;
int kazanilanGanimet = 0;
int gidilecekNum = 0;

// fonksiyon prototipleri
void KampalaniFunction();
void SifahaneFunction();
void HanFunction();
void MacerayaAtilFunction();
void DurumFunction();
void SeviyeFunction();
void HaydutSavasFunction(int hayCev, int hayGuc, int hayDay, int hayCan);
void KesifFunction(int max, int min, char mekan[]);
void NiteligeEkleFunction(int *kotrolEdilecek, int eklenecekMik, char isim[]);
void NiteliktenCikarFunction(int *kotrolEdilecek, int cikacakMik, char isim[]);
void KampAtesi();

#define satir 26
#define sutun 69

// Oyunu haritası
char harita[satir][sutun] = {
    "______________________________|           |_________________________",
    "|   |   |                                                          |",
    "|   |   |          ________                 ________               |",
    "|    |   |        |        |               |        |              |",
    "|     |   |       |  Kamp  |               |  Sifa  |              |",
    "|     |   |       |  Alani |               |  Hane  |              |",
    "|______|   |______|____   _|_______________|__   ___|______________|",
    "|      | H |           |  |                   |  |                 |",
    "|     | U |            |  |                   |  |                 |",
    "|     | Z |            |  |                   |  |                 |",
    "|    | U |             |  |____               |  |                 |",
    "|   | R |             |        |              |  |                 |",
    "|  |   |              |  Koy   |______________|  |                 |",
    "|  | N |              | Meydani _________________|                 |",
    "|__| E |______________|__   ___|___________________________________|",
    "| | H |                  | |                                       |",
    "|  | R |          _______| |              ________                 |",
    "|  | I |         |         |             |        |                |",
    "|    |   |       |  Han    |             |  Vadi  |                |",
    "|      |   |     |_________|             |________|                |",
    "|        |   |                    _____                            |",
    "|        |   |    ________       |     |               ____________|",
    "|       |   |    |        |      | Gol |              |            |",
    "|      |   |     | Orman  |      |_____|              | Kayakliklar|",
    "|      |   |     |________|                           |____________|",
    "|_____|___|________________________________________________________|"};

void HaritayiGoster(int X, int Y) // Oyunun haritasi konsolda göstermek
{
    printf("\n\tAsagidaki haritada '#' isareti ile konumunuzu ogrenebilirsiniz!\n\n");

    for (int i = 0; i < satir; i++)
    {
        for (int j = 0; j < sutun; j++)
        {
            if (i == X && j == Y)
            {
                // Ozanin yeri gösterir
                printf("#");
            }
            else
            {
                // Orijinal haritayı gösterir
                printf("%c", harita[i][j]);
            }
        }
        printf("\n");
    }
}

// Ana menü
void MenuFunction()
{
    gidilecekNum = 0;
    char cikis[5];
    while (1)
    { // Menü sürekli olarak dönecek
        printf("\n----------------------------------MENU-------------------------------\n\n");
        HaritayiGoster(14, 26);
        printf("\nKamp alnina git (1) \nSifahaneye git (2) \nHana git (3) \nMaceraya atil (4) \nSeviye atla (5) \nDurumu goster (6) \nOyundan cik (7)\n");
        printf("Gitmek istediginiz yerin NUMARASINI giriniz : ");

        if (scanf(" %d", &gidilecekNum) != 1)
        { // Eğer sayı okunamazsa
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                ;     // Tamponu temizle- onceeden kalan kirintilar temizlenir
            continue; // Menü başına dön
        }

        switch (gidilecekNum)
        {
        case 1: // Kamp alnına gitmek durumu
            printf("\nKamp alanina gidiliyor...\n");
            KampalaniFunction();
            break;
        case 2: // Şifahaneye gitmek durumu
            printf("\nSifahaneye gidiliyor...\n");
            SifahaneFunction();
            break;
        case 3: // Hana gitmek durumu
            printf("\nHana gidiliyor...\n");
            HanFunction();
            break;
        case 4: // Maceraya atılınmaya durumu
            printf("\nMaceraya atilinmaya gidiliyor...\n");
            MacerayaAtilFunction();
            break;
        case 5:
        { // Seviye atlama durumu
            int secim;
            printf("\nSeviye atlama menusu aciliyor...\n");
            printf("Seviyeniz : %d\n", seviye);
            printf("Seviye atlamaniz icin kalan tecrube miktariniz : %d\n", 100 - tecrube);
            printf("Menuye geri donmek icin konsola \"1\" giriniz : ");
            if (scanf(" %d", &secim) != 1)
            { // Eğer sayı okunamazsa
                printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
                while (getchar() != '\n')
                    ;     // Tamponu temizle- onceeden kalan kirintilar temizlenir
                continue; // Menü başına dön
            }
            else
            {
                MenuFunction();
            }
            break;
        }
        case 6:
            // Ozanın durumu gostermk için
            printf("\nDurum gostergesi aciliyor...\n");
            DurumFunction();
            break;
        case 7:
            // Oyundan çıkma durumu
            printf("\nOyundan cikmak istedigine emin misiniz?\nKonsola (evet/hayir) yaziniz : \n");
            scanf(" %s", &cikis);
            if (strcmp(cikis, "evet") == 0)
            {
                printf("\nOyundan cikiliyor...\n");
                exit(0);
                break;
            }
            else
            {
                // Oyundan çıkmak vazgeçmek istenirse ana menüye döner
                printf("\nAna menuye yonlendiriliyorsunuz...\n");
                MenuFunction();
                break;
            }
        default:
            printf("Gecersiz giris...\n");
            break;
        }
    }
}

void KampalaniFunction() // Kamp alanına gittikten sonra neler yapabilecek gösteren bir fonksiyonu
{
    gidilecekNum = 0;
    HaritayiGoster(6, 24);

    while (1)
    { // Menü sürekli olarak dönecek
        printf("\n---------------KAMP ALANI---------------\n");
        printf("\nNehirde yikan (1) \nDisini fircala (2) \nCadirina girip uyu (3) \nGun batisi izle (4) \nKamp atesi yakmak (5) \nKoy meydanina don (6) \n");
        printf("Gitmek istediginiz yerin NUMARASINI giriniz : ");

        if (scanf(" %d", &gidilecekNum) != 1)
        { // Eğer sayı okunamazsa
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                ;     // Tamponu temizle- onceeden kalan kirintilar temizlenir
            continue; // Menü başına dön
        }

        switch (gidilecekNum)
        {
        case 1: // Nehirde yıkanma seçeniği
        {
            int secim = 0;
            printf("\nNehre giriliyor...\n");
            HaritayiGoster(5, 7);
            printf("\nYilin bu zamani nehir suyu soguk oluyor.\nSence suya direk girmeli miyim (1) yoksa yavasca ve alisarak mi gireyim (2) : \n");
            scanf(" %d", &secim);
            switch (secim)
            {
            case 1: // Suya direk girmek
                printf("\nOoo, su gercekten sogukmus!!\n");
                NiteliktenCikarFunction(&huzur, 5, "huzur");
                NiteligeEkleFunction(&hijyen, 25, "hijyen");
                NiteliktenCikarFunction(&uyku, 10, "uyku");
                KampalaniFunction();
                break;
            case 2: // Suya yavaşça girmek
                printf("\nBu, hayatin boyunca verdigin en matikli karar olabilir.Suya birden atlayanlari hic anlamiyorum.\n");
                NiteligeEkleFunction(&huzur, 10, "huzur");
                NiteligeEkleFunction(&hijyen, 25, "hijyen");
                NiteliktenCikarFunction(&uyku, 10, "uyku");
                KampalaniFunction();
                break;
            default:
                if (scanf(" %d", &secim) != 1 || scanf(" %d", &secim) != 2)
                { // Eğer sayı okunamazsa
                    printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
                    while (getchar() != '\n')
                        ;     // Tamponu temizle- önceden kalan kirintilar temizlenir
                    continue; // Menü başına dön
                }
                break;
            }

            break;
        }
        case 2: // Dişler fırçalama seçeniği
            printf("\nDisler fircalaniyor...\n");
            NiteligeEkleFunction(&hijyen, 10, "hijyen");
            KampalaniFunction();
            break;
        case 3: // Çadırda uyumak seçeniği
            printf("\nCadira gidilip uyunuyor...\n");
            printf("\t   .\n\t  z\n\t z\n\tZ\n");
            NiteligeEkleFunction(&uyku, 30, "uyku");
            NiteligeEkleFunction(&huzur, 10, "huzur");
            NiteliktenCikarFunction(&hijyen, 10, "hijyen");
            NiteliktenCikarFunction(&tokluk, 7, "tokluk");
            KampalaniFunction();
            break;

        case 4: // Gün batımı izlemek seçeniği
            printf("\nGun batimini izlerken, yarinin hangi maceralari barindirdigini dusunuyorum.\n");
            NiteligeEkleFunction(&huzur, 5, "huzur");
            NiteligeEkleFunction(&uyku, 10, "uyku");
            KampalaniFunction();
            break;

        case 5:          // Kamp ateşi seçeniği
            KampAtesi(); // Ateşin etrafında neler yapaılacak
            KampalaniFunction();
            break;

        case 6:
            printf("\nKoy meydanina donuluyor...\n");
            MenuFunction(); // Ana menüye dön
            break;
        default:
            printf("\nGecersiz giris...\n");
            break;
        }
    }
}

void KampAtesi() // Kamp ateşi yaktiktan sonra neler yapabilecek gösteren bir fonksiyonu
{
    int gidilecekNum;

    while (1) // Menü sürekli olarak dönecek
    {
        printf("\n      .\n     .*.\n   .* . .  \n   *..*.*  \n >========<\n");

        printf("\nKamp atesi yakiliyor...\n");
        printf("\nAtesin etrafinda ne yapmak istiyorsun?\nSarki soylemek (1)\nMarshmello kizartmak (2)\nYildizlara bakmak (3)\nKitap okumak (4)\nAtesi sondurmek (5)\nKamp alanina geri don (6)\n");

        if (scanf(" %d", &gidilecekNum) != 1)
        {
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                continue;
        }

        switch (gidilecekNum)
        { // Kamp ateşi etrafında şarkı söylemek
        case 1:
            printf("\nSarki soyleniyor...\n");
            NiteligeEkleFunction(&huzur, 10, "huzur");
            NiteligeEkleFunction(&karizma, 2, "karizma");
            KampAtesi();
            break;
        case 2:
            // Kamp ateşi üzerinde marshmello kizartmak
            printf("\nMarshmello kizartiliyor...\nCok sekerli ama cok lezzetli!\n");
            NiteligeEkleFunction(&tokluk, 5, "tokluk");
            KampAtesi();
            break;
        case 3:
            // Yıldızlara bakmak
            printf("\nBu yildizlar kediye benziyorlar...\n");
            NiteligeEkleFunction(&huzur, 15, "huzur");
            NiteligeEkleFunction(&odaklanma, 5, "odaklanma");
            KampAtesi();
            break;
        case 4:
            // Kamp ateşin etrafında kitap okumak
            printf("\nKitap okunuyor...\n");
            NiteligeEkleFunction(&odaklanma, 10, "odaklanma");
            NiteliktenCikarFunction(&uyku, 5, "uyku");
            KampAtesi();
            break;
        case 5:
            // Atesi söndürmek
            printf("\n    .  ..  .\n   >=========<\n\n");
            printf("Cssss!");
            printf("\nAtesi sondurdunuz...\n");
            NiteliktenCikarFunction(&uyku, 5, "uyku");
            break;
        case 6:
            KampalaniFunction();
            break;
        default:

            break;
        }
    }
}

void SifahaneFunction() // Şifahaneye gittikten sonra neler yapabilecek gösteren bir fonksiyonu
{
    gidilecekNum = 0;
    HaritayiGoster(6, 47);
    while (1)
    { // Menü sürekli olarak dönecek
        printf("\n---------------SIFAHANE----------------\n");
        printf("\nSifacidan yaralarini sarmasini iste (1) \nSifacidan merhem yapip surmesini iste (2) \nMeditasyon yap (3) \nKoy meydanina don (4) \n");
        printf("Gitmek istediginiz yerin NUMARASINI giriniz : ");

        if (scanf(" %d", &gidilecekNum) != 1)
        { // Eğer sayı okunamazsa
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                ;     // Tamponu temizle- onceeden kalan kirintilar temizlenir
            continue; // Menü başına dön
        }

        switch (gidilecekNum)
        {
        case 1: // Sifacidan yaralarını için sarmasını istemek
            printf("\nSifacidan yaralarini sarmasi isteniyor...\n");
            NiteligeEkleFunction(&huzur, 5, "huzur");
            SifahaneFunction();
            break;
        case 2:
        { /*Merhem sürmek.
          Burada merhemin tipine göre fiyatı değişecek.*/
            printf("\nSifacidan merhem yapip surmesini isteniyor...\n");
            printf("Sifacinin size 3 merhem tavsiyesi var :");
            printf("\n1.Hafif Merhem\t: Hafif agrilarini azaltacaktir.\n-5 para\t+5 can\n");
            printf("\n2.Guclu Merhem\t: Agrilarini giderir ancak yaralarini tamamen taedavi edemez.\n-20 para\t+20 can\n");
            printf("\n3.Mucizevi Merhem\t: Hic bir agri ve yaran kalmayacak.\n-50 para\t+50 can\n");
            printf("Sectigin merhemin numarasini gir : ");
            scanf(" %d", &merhemNum);
            switch (merhemNum)
            {
            case 1: // Hafif merhem
                if (para >= 5)
                {
                    NiteligeEkleFunction(&can, 5, "can");
                    NiteliktenCikarFunction(&para, 5, "para");
                }
                else
                { // yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!");
                }
                break;
            case 2: // Güçlü Merhem
                if (para >= 20)
                {
                    NiteligeEkleFunction(&can, 20, "can");
                    NiteliktenCikarFunction(&para, 20, "para");
                }
                else
                { // yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!");
                }
                break;
            case 3: // Mucizevi Merhem
                if (para >= 50)
                {
                    NiteligeEkleFunction(&can, 50, "can");
                    NiteliktenCikarFunction(&para, 50, "para");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!");
                }
                break;
            default:
                printf("gecersiz giris");
                break;
            }
            NiteligeEkleFunction(&huzur, 10, "huzur");
            break;
        }
        case 3: // Meditasyon yapma durumu
            printf("\nMeditasyon yapiliyor...\n");
            printf("Omm.. oomm.. Oommm...\n");
            NiteligeEkleFunction(&huzur, 15, "huzur");
            NiteliktenCikarFunction(&tokluk, 7, "tokluk");
            NiteliktenCikarFunction(&uyku, 10, "uyku");
            break;
        case 4: // Ana menüye donmek
            printf("\nKoy meydanina donuluyor...\n");
            MenuFunction();
            break;
        default:
            printf("\nGecersiz giris...\n");
            break;
        }
    }
}

void HanFunction()
{
    HaritayiGoster(18, 25);
    gidilecekNum = 0;
    while (1)
    { // Menü sürekli olarak dönecek
        printf("\n---------------HAN---------------\n");
        printf("\nYiyecek satin al ve ye (1) \nIcecek satin al, ic, eglen (2) \n%s cal ve sarki soyle (3) \nKoy meydanina don (4) \n", calgi);
        printf("Gitmek istediginiz yerin NUMARASINI giriniz : ");

        if (scanf(" %d", &gidilecekNum) != 1)
        { // Eğer sayı okunamazsa
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                ;     // Tamponu temizle- onceeden kalan kırıntılar temizlenir
            continue; // Menü başına dön
        }

        // girilen numaraya göre gidilecek mekan-fonksiyon
        switch (gidilecekNum)
        {
        case 1: // Yiyecek satın al ve ye. Yemeğe göre fiyatları değişecek.
        {
            int yiyecekSecimi = 0;
            printf("\n\nHancinin size 3 yemek onerisi var : \n Meyve(1)\t:\tpara: -5\ttokluk: +5\n Ekmek(2)\t:\tpara: -10\ttokluk: +10\n Yahni(3)\t:\tpara: -25\ttokluk: +25\nAlmaya karar verdiginiz yiyecegin numarasini giriniz (1)(2)(3) : ");
            scanf(" %d", &yiyecekSecimi);
            switch (yiyecekSecimi)
            {
            case 1: // Meyve yemek
                if (para >= 5)
                {
                    printf("\nHmm bu meyveler cok taze, artik daha dinc hissediyorum :)\n");
                    NiteligeEkleFunction(&tokluk, 5, "tokluk");
                    NiteliktenCikarFunction(&para, 5, "para");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!\n");
                }

                break;
            case 2: // Ekmek yemek
                if (para >= 10)
                {
                    printf("\nHmm bu ekmek cok sicak, firindan yeni cikmis olmali :)\n");
                    NiteligeEkleFunction(&tokluk, 10, "tokluk");
                    NiteliktenCikarFunction(&para, 10, "para");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!\n");
                }
                break;
            case 3: // Yahni yemek

                if (para >= 25)
                {
                    printf("\nHmm bu yahni cok leziz gorunuyor :)\n");

                    NiteligeEkleFunction(&tokluk, 25, "tokluk");
                    NiteliktenCikarFunction(&para, 25, "para");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!\n");
                }

                break;
            default:
                printf("\nGecersiz deger girisi!\n");
                break;
            }
            HanFunction();
            break;
        }
        case 2: // İçecek satın al ve ye. İçeceğe göre fiyatları değişecek.
        {
            int icecekSecimi = 0;
            printf("\n\nHancinin size 3 icecek onerisi var : \n Su(1)\t\t:\tpara: -5\tsivi seviyesi miktari: +5 \n Cay(2)\t\t:\tpara: -10\tsivi seviyesi miktari: +10\tuyku miktari: +5\n Kahve(3)\t:\tpara: -15\tsivi seviyesi miktari: +15\tuyku miktari: +10\nAlmaya karar verdiginiz yiyecegin numarasini giriniz (1)(2)(3) : ");
            scanf(" %d", &icecekSecimi);
            switch (icecekSecimi)
            {
            case 1: // Su icmek
                if (para >= 5)
                {
                    printf("\nOhh bu kadar susadigimi farketmemistim!\n");
                    NiteligeEkleFunction(&siviSeviyesi, 5, "sivi");
                    NiteliktenCikarFunction(&para, 5, "para");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!\n");
                }
                break;
            case 2: // Çay icmek

                if (para >= 10)
                {
                    NiteligeEkleFunction(&siviSeviyesi, 10, "sivi");
                    NiteliktenCikarFunction(&para, 10, "para");
                    NiteligeEkleFunction(&uyku, 5, "uyku"); // cay icince insanin uykuyu hissetmesi azalir bu yuzden ozanin da uyku miktarini artirdik.
                    printf("\nBu cay iyi demlemendi !\n");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK\n!");
                };
                break;
            case 3: // Kahve icmek
                if (para >= 15)
                {
                    NiteligeEkleFunction(&siviSeviyesi, 15, "sivi seviyesi");
                    NiteliktenCikarFunction(&para, 15, "para");
                    NiteligeEkleFunction(&uyku, 10, "uyku"); // kahve icince insanin uykuyu hissetmesi azalir bu yuzden ozanin da uyku miktarini artirdik.
                    printf("\nBu kahve, gunume enerji katti :D\n");
                }
                else
                { // Yetersiz para durumu
                    printf("\nYETERLI PARAN YOK!\n");
                }

                break;
            default:
                printf("\nGecersiz deger girisi\n!");
                break;
            }
            HanFunction();
            break;
        }
        case 3:
            // handa başarılı bir şekilde şarkı söyleyebilirse para, tecrube ve karizma kazanıyor
            if (hijyen > 20) // Hiyjen 20'den fazla olmalı
            {
                para = para + (10 + karizma * (hijyen / 100));
                tecrube += 20;
                printf("\n%s caliniyor ve sarki soyleniyor...\n", calgi);
                NiteligeEkleFunction(&karizma, 5, "karizma");
                printf("Yeni para miktarin\t: %d\nYeni tecrube miktarin\t: %d", para, tecrube);
                SeviyeFunction();
            }
            else
            { // Başrısız durumunda
                printf("Hijyenin (%d) YETERLI SEVIYEDE DEGIL!\nEn az 20 hijyen puanina sahip olmalisin! ", hijyen);
                HanFunction();
            }
            HanFunction();
            break;
        case 4: // Ana menüye dönmek
            printf("\nKoy meydanina donuluyor...\n");
            MenuFunction();
            break;
        default:
            printf("\nGecersiz giris...\n");
            break;
        }
    }
}

void HaydutKacFunction(int hayCev, int hayGuc, int hayDay, int hayCan) // Savaştan kaçma fonksiyonu
{                                                                      // Random olarak hayduttan kaçma olasılığının hesaplanması...
    float y = ceviklik * 4.0 / 100;
    int x = rand() % 101;
    printf("\n\n%d\n", x);
    printf("Hayduttan kacma sansin : %%%.2f\n\n", y * 100);
    printf("Hayduttan kacmaya calisiliyor...");
    if (x <= y * 100)
    { // Başarılı bir şekilde hayduttan kaçıldı
        printf("\nOhh, ucuz atlattin, hayduttan kacmayi basardin!\n");
    }
    else
    { // Başarısız bir şekilde hayduttan kaçıldı
        printf("\nHay aksi, hayduta yakalandin.\nSAVAS BASLIYOR...\n");

        HaydutSavasFunction(hayCev, hayGuc, hayDay, hayCan);
    }
}
void HaydutBaslar(int hayCev, int hayGuc, int hayDay, int hayCan)
{ // Savaşta haydut ilk başlama durumunda ...

    int saldiraninVerdigiHasar = 4 * hayGuc; // saldiranin verdiği hasar haydut->ozan. haydut: saldıran, ozan :savunan
    int alinanHasar = saldiraninVerdigiHasar - (saldiraninVerdigiHasar * 4 * dayaniklilik / 100 - 1);
    can -= alinanHasar;
    if (can <= 0)
    { // Savaşta ölme durumu
        printf("\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");
        printf("Maalesef savasi kaybettin.\nCanin 0'landigi icin oyun sona erdi.\nOyundan cikiliyor...\n");
        printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");

        exit(0);
    }
    int savas = 0;
    printf("Can kaybediyorsun.\tYeni can degerin : %d\n", can);
    printf("Kacmayi denemek ister misin AMA eger kacamazsan bu turunu harcamis olacaksin ve sira yine hayduta gececek!\nKacmak:0\tSavasa devam:1\n");
    scanf(" %d", &savas);
    switch (savas)
    {
    case 0:
    {
        // Savaştan kaçabilime seçeniği
        HaydutKacFunction(hayCev, hayGuc, hayDay, hayCan);
        break;
    }

    case 1:
    { // Savaşı devam etmesi seçeniği
        int savunaninVerdigiHasar = 4 * guc;
        int verilenHasar = savunaninVerdigiHasar - (savunaninVerdigiHasar * 4 * hayDay / 100 - 1);
        hayCan -= verilenHasar;
        if (hayCan <= 0)
        { // Savaşta kazanma durumu
            printf("Tebrikler, haydutu altettin!\n");
            tecrube += kazanilacakTecrube;
            para += kazanilanGanimet;
            printf("%d tecrube puani kazandin.\nYeni tecrube degerin\t: %d\n", kazanilacakTecrube, tecrube);
            printf("Ganimet ile %d para kazandin.\nYeni para degerin\t: %d\n", kazanilanGanimet, para);
            NiteligeEkleFunction(&odaklanma, 10, "odaklanma");
            NiteliktenCikarFunction(&huzur, 30, "huzur");
            NiteliktenCikarFunction(&hijyen, 15, "hijyen");
            NiteliktenCikarFunction(&tokluk, 30, "tokluk");
            NiteliktenCikarFunction(&uyku, 20, "uyku");

            MenuFunction();
        }
        printf("Hayduta agir bir darbe vurdun!\tHaydutun can degeri : %d\n", hayCan);
        while (hayCan > 0 && can > 0)
        { // Savaş devam ediyor...
            HaydutSavasFunction(hayCev, hayGuc, hayDay, hayCan);
        }

        break;

    default:
        printf("Yanlis bir deger girdiniz!");
        break;
    }
    }
}
void OzanBaslar(int hayCev, int hayGuc, int hayDay, int hayCan)
{ // Savaşta Ozan ilk başlama durumunda ...
    int savunaninVerdigiHasar = 4 * guc;
    int verilenHasar = savunaninVerdigiHasar - (savunaninVerdigiHasar * 4 * hayDay / 100 - 1);
    hayCan -= verilenHasar;
    if (hayCan <= 0)
    { // Savaşta kazanma durumu
        printf("Tebrikler, haydutu altettin!\n");
        tecrube += kazanilacakTecrube;
        para += kazanilanGanimet;
        printf("%d tecrube puani kazandin.\nYeni tecrube degerin\t: %d\n", kazanilacakTecrube, tecrube);
        printf("Ganimet ile %d para kazandin.\nYeni para degerin\t: %d\n", kazanilanGanimet, para);

        NiteligeEkleFunction(&odaklanma, 10, "odaklanma");
        NiteliktenCikarFunction(&huzur, 30, "huzur");
        NiteliktenCikarFunction(&hijyen, 15, "hijyen");
        NiteliktenCikarFunction(&tokluk, 30, "tokluk");
        NiteliktenCikarFunction(&uyku, 20, "uyku");
        MenuFunction();
    }
    printf("Hayduta agir bir darbe vurdun!\tHaydutun can degeri : %d\n", hayCan);

    int saldiraninVerdigiHasar = 4 * hayGuc; // Saldiranin verdiği hasar haydut->ozan. haydut: saldıran, ozan :savunan
    int alinanHasar = saldiraninVerdigiHasar - (saldiraninVerdigiHasar * 4 * dayaniklilik / 100 - 1);
    can -= alinanHasar;
    if (can <= 0)
    { // Savaşta ölme durumu
        printf("\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");
        printf("Maalesef savasi kaybettin.\nCanin 0'landigi icin oyun sona erdi.\nOyundan cikiliyor...\n");
        printf("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");

        exit(0);
    }
    int savas = 0;
    printf("Can kaybediyorsun.\tYeni can degerin : %d\n", can);
    NiteliktenCikarFunction(&huzur, 10, "huzur");
    NiteliktenCikarFunction(&hijyen, 5, "hijyen");
    printf("Kacmayi denemek ister misin AMA eger kacamazsan bu turunu harcamis olacaksin ve sira yine hayduta gececek!\nKacmak:0\tSavasa devam:1\n");
    scanf(" %d", &savas);
    switch (savas)
    {
    case 0:
    { // Savaştan kaçmak seçeniği
        HaydutKacFunction(hayCev, hayGuc, hayDay, hayCan);
        break;
    }

    case 1:
    {
        while (hayCan > 0 && can > 0)
        { // Savaşı devam etmesi seçeniği
            HaydutSavasFunction(hayCev, hayGuc, hayDay, hayCan);
        }

        break;

    default:
        printf("Yanlis deger girdiniz!");

        break;
    }
    }
}
void HaydutSavasFunction(int hayCev, int hayGuc, int hayDay, int hayCan)
{
    if (hayCev > ceviklik) // Haydut daha çevikse önce o başlayacak
    {
        HaydutBaslar(hayCev, hayGuc, hayDay, hayCan);
    }
    else if (ceviklik > hayCev)
    {
        OzanBaslar(hayCev, hayGuc, hayDay, hayCan);
    }
    else
    {
        // Ceviklikler esit ise %50 ihtimal ile kimin baslayacagı secilir.
        int kiminBaslayacak = rand() % 2;

        if (kiminBaslayacak == 0)
        { // Haydut ilk başlar
            HaydutBaslar(hayCev, hayGuc, hayDay, hayCan);
        }
        else if (kiminBaslayacak == 1)
        { // Ozan ilk başlar
            OzanBaslar(hayCev, hayGuc, hayDay, hayCan);
        }
        else
        {
            printf("Hatali giris! Haydut veya Macera seciniz.\n");
        }
    }
};

void MacerayaAtilFunction()
{ // Maverya atılma durumunda nelere yapabilecek gösteren bir fonksiyonu
    gidilecekNum = 0;
    while (1)
    { // Menü sürekli olarak dönecek
        printf("\n---------------MACERAYA ATIL---------------\n");
        printf("\nYakin cevreden sifali bitki topla ve eglen (1) \nOrmani kesfe cik [KOLAY] (2) \nKayaliklari kesfe cik [ORTA] (3) \nVadiyi kesfe cik [ZOR] (4) \nCimlerde kestir (5)\nNehre karsi uzan (6)\nGolde yuz (7)\nKoy meydanina don (8) \n", calgi);
        printf("Gitmek istediginiz yerin NUMARASINI giriniz : ");
        if (scanf(" %d", &gidilecekNum) != 1)
        { // Eğer sayı okunamazsa
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                ;     // Tamponu temizle- önceden kalan kırıntılar temizlenir
            continue; // Menü başına dön
        }

        switch (gidilecekNum)
        {
        case 1: /*Yakın çevreden şifali bitki toplama ve eğlenme.
                Toplayıcılık seviyesine göre farklı bir bitki veya hayvan bulunacak.*/
        {
            int sayi = rand() % 101;
            int sayi2 = rand() % 101;
            float sifaliBitkiBulmaSansi = toplayicilik * 4.0 / 100;
            float meyveBulmaSansi = toplayicilik * 4.0 / 100;
            float hayvanBulmaSansi = toplayicilik * 4.0 / 2 / 100;
            printf("\nYakin cevreden sifali bitki toplanip egleniliyor...\n");

            // Bitki toplama
            if (toplayicilik == 0)
            {
                printf("Toplayicilik degerin dusuk, bitki-meyve-hayvan bulma ihtimalin yok!\n");
            }
            else if (sayi <= sifaliBitkiBulmaSansi * 100)
            {
                printf("Tebrikler! Sifali bir bitki buldun!\t\t");
                NiteligeEkleFunction(&can, 10, "can");
                NiteligeEkleFunction(&odaklanma, 15, "odaklanma");
            }
            else
            {
                printf("Maalesef bu bitkiler hic de sifali gorunmuyor !\n");
            }

            // Meyve bulma
            if (sayi2 <= meyveBulmaSansi * 100)
            {
                printf("Tebrikler! Sulu bir meyve buldun!\t\t");
                NiteligeEkleFunction(&tokluk, 10, "tokluk");
            }
            else
            {
                printf("Iyy bu meyveler hep kurtlanmis!\n");
            }

            // Hayvan avlama
            if (sayi <= hayvanBulmaSansi * 100)
            {
                printf("Tebrikler! Iri bir av hayvani yakaladin!\t");
                NiteligeEkleFunction(&tokluk, 50, "tokluk");
            }
            else
            {
                printf("Hay aksi hayvani iskaladin!\n");
            }

            MacerayaAtilFunction();
            break;
        }

        case 2: // Ormanı keşfetme durumu
        {
            HaritayiGoster(22, 22); // Ozanın yeni konumu göster haritada
            kazanilacakTecrube = 30;
            kazanilanGanimet = rand() % (25 - 15 + 1) + 15;
            KesifFunction(3, 1, "Orman"); // 1-3 arasında rastgele güç, çeviklik ve dayanıklılık değerleri
            SeviyeFunction();
            MacerayaAtilFunction();
            break;
        }

        case 3:                     // Kayakları keşfetme durumu
            HaritayiGoster(22, 60); // Ozanın yeni konumu göster haritada
            kazanilacakTecrube = 60;
            kazanilanGanimet = rand() % (50 - 30 + 1) + 30;
            KesifFunction(6, 4, "Kayaliklar"); // 4-6 arasında rastgele güç, çeviklik ve dayanıklılık değerleri
            SeviyeFunction();
            MacerayaAtilFunction();
            break;
        case 4:                     // Vadiyi keşfeteme durumu
            HaritayiGoster(17, 46); // Ozanın yeni konumu göster haritada
            kazanilacakTecrube = 90;
            kazanilanGanimet = rand() % (75 - 55 + 1) + 55;
            KesifFunction(10, 7, "Vadi"); // 7-10 arasında rastgele güç, çeviklik ve dayanıklılık değerleri
            SeviyeFunction();
            MacerayaAtilFunction();
            break;
        case 5: // Çimlerde kestirmek durumu
            printf("\nCimlere gidiliyor...\n");
            printf("\nCimlerin ruzgarla salinimi gercekten de cok rahatlatici, en iyisi biraz kestireyim...\n");
            printf("\t   .\n\t  z\n\t z\n\tZ\n");
            NiteligeEkleFunction(&uyku, 20, "uyku");
            NiteligeEkleFunction(&huzur, 7, "huzur");
            NiteliktenCikarFunction(&hijyen, 5, "hijyen");
            NiteliktenCikarFunction(&tokluk, 2, "tokluk");
            MenuFunction();
            break;
        case 6: // Nehrin karşısına uzanma durumu
            HaritayiGoster(22, 13);
            printf("\nNehre karsi uzaniliyor...\n");
            printf("\nNehir suyunun sesi beni cok huzurlu hissettiriyor, en iyisi biraz kestireyim...\n");
            printf("\t   .\n\t  z\n\t z\n\tZ\n");
            NiteligeEkleFunction(&uyku, 15, "uyku");
            NiteligeEkleFunction(&huzur, 7, "huzur");
            NiteliktenCikarFunction(&hijyen, 5, "hijyen");
            NiteliktenCikarFunction(&tokluk, 2, "tokluk");
            MenuFunction();
            break;
        case 7: // Gölde yüzme durumu
        {
            int sayi = rand() % 101;
            char secim;
            float balikTutmaSansi = ceviklik * 4.0 / 100;
            printf("\nGole giriliyor...\n");
            HaritayiGoster(21, 37);
            printf("Neden bilmiyorum ama gol nehre gore daha sicak oluyor :)");
            printf("Aaa, suna bak bir balik surusu!\nSence bir tane yakalayabilir miyim?\n\t(E/H) : ");
            scanf(" %c", &secim);
            switch (secim)
            {
            case 'E':
            case 'e':
                // Yüzerken gölde balık tutmak istenirse çeviklik değerine göre balığı tutup tutmadığını belli olur
                if (ceviklik == 0)
                {
                    printf("Ceviklik degerin dusuk, balik tutma ihtimalin yok!\n");
                }
                else if (sayi <= balikTutmaSansi * 100)
                {
                    printf("Tebrikler! Iri bir balik yakaladin!\t\t");
                    NiteligeEkleFunction(&odaklanma, 5, "odaklanma");
                }
                else
                {
                    printf("Hay aksi, balik nasil da kaciverdi!\n");
                    NiteliktenCikarFunction(&odaklanma, 5, "odaklanma");
                }
                break;
            case 'H':
            case 'h':
                printf("Yuzmeye devam o halde.\n");

                break;

            default:
                printf("Gecersiz veri girisi.\n");
                break;
            }
            NiteligeEkleFunction(&hijyen, 15, "hijyen");
            NiteliktenCikarFunction(&uyku, 5, "uyku");
            MacerayaAtilFunction();
            break;
        }
        case 8: // Ana menüye dönme
            printf("\nKoy meydanina donuluyor...\n");
            MenuFunction();
            break;
        default:
            printf("\nGecersiz giris...\n");
            break;
        }
    }
}

void KesifFunction(int max, int min, char mekan[])
{ // Keşfe çıktıüı yerlerde Ozanın haydutla karşılaşması ondan kaça veye onunla savaşma seçeneklerinin sunulması
    // Keşfe seviyesine göre haydutun  becereli random olarak oluşturulur.
    int haydutGuc = rand() % (max - min + 1) + min;

    int haydutCeviklik = rand() % (max - min + 1) + min;

    int haydutDayaniklilik = rand() % (max - min + 1) + min;

    int haydutCan = can;
    int savas = 0;
    printf("\n%s kesfe cikiliyor...\n", mekan);

    printf("\n!!! HAYDUT BECERILERI !!!\n");
    printf("\nhaydut gucu\t\t: %d\nhaydut cevikligi\t: %d\nhaydut dayanikliligi\t: %d", haydutGuc, haydutCeviklik, haydutDayaniklilik);
    printf("\nsenin gucun\t\t: %d\nsenin cevikligin\t: %d\nsenin dayanikliligin\t: %d\n", guc, ceviklik, dayaniklilik);
    printf("Savasacak misin(1) yoksa kacacak misin(0)?\nCevabiniza gore 1 veya 0 giriniz : ");
    scanf(" %d", &savas);

    switch (savas)
    {

    case 0: // Kaçmak
        HaydutKacFunction(haydutCeviklik, haydutGuc, haydutDayaniklilik, haydutCan);
        break;

    case 1: //  Savaşlamak
        HaydutSavasFunction(haydutCeviklik, haydutGuc, haydutDayaniklilik, haydutCan);
        break;

    default:
        break;
    }
}

void DurumFunction()
{
    int secim;
    while (1)
    { // Menü sürekli olarak dönecek
        printf("\n---------------DURUM---------------\n");
        printf("\nPara\t:%d\nSeviye\t:%d\nTecrube\t:%d\n", para, seviye, tecrube);
        printf("\n*** temel nitelikler ***");
        printf("\nCan\t\t:%d\nTokluk\t\t:%d\nUyku\t\t:%d\nHijyen\t\t:%d\nHuzur\t\t:%d\nSivi Seviyesi\t:%d\nOdaklanma\t:%d\n", can, tokluk, uyku, hijyen, huzur, siviSeviyesi, odaklanma);
        printf("\n*** beceriler ***");
        printf("\nGuc\t\t:%d\nCeviklik\t:%d\nDayaniklilik\t:%d\nKarizma\t\t:%d\nToplayicilik\t:%d\n", guc, ceviklik, dayaniklilik, karizma, toplayicilik);
        printf("Menuye geri donmek icin konsola \"1\" giriniz : ");
        if (scanf(" %d", &secim) != 1)
        { // Eğer sayı okunamazsa
            printf("Gecersiz giris... Lutfen bir sayi giriniz!\n");
            while (getchar() != '\n')
                ;     // Tamponu temizle- onceeden kalan kirintilar temizlenir
            continue; // Menü başına dön
        }
        else
        {
            MenuFunction(); // Ana menüye dönmek
        }
    }
}

void SeviyeFunction() // Seviye atlama fonksiyonu
{
    if (tecrube >= 100)
    {
        seviye += 1;
        printf("\nTEBRIKLER SEVIYE ATLADINIZ !\n");
        // Seviye atlama menusune gec
        tecrube = 0;
        printf("\nTecrube puaniniz sifirlanmistir.");
        printf("\nSeviye atladiginiz icin sececeginiz becerilerinizde kullanilmak uzere toplam 5 puan verilecektir");

        for (; beceriPuani > 0;) // kazandğı 5 puanı dağtmak için for dögüsü.
        {
            printf("\n(1)guc= %d, (2)ceviklik= %d, (3)dayaniklilik= %d, (4)karizma= %d, (5)toplayicilik= %d\nBecerinizi secin : ", guc, ceviklik, dayaniklilik, karizma, toplayicilik);
            scanf(" %d", &beceriSecimi);
            printf("\nAktarmak icin %d puaniniz var.\nSectiginiz beceriye aktarilacak puani giriniz : ", beceriPuani);
            scanf(" %d", &beceriyeAktarilacakPuan);
            if (beceriyeAktarilacakPuan < 0 || beceriyeAktarilacakPuan > beceriPuani)
            {
                printf("\nGECERSIZ PUAN GIRISI!");
                continue;
            }
            else
            {
                switch (beceriSecimi)
                {
                case 1: // Güçü artırmak
                    NiteligeEkleFunction(&guc, beceriyeAktarilacakPuan, "guc");
                    beceriPuani -= beceriyeAktarilacakPuan;
                    break;
                case 2: // Çeviklik artırmak
                    NiteligeEkleFunction(&ceviklik, beceriyeAktarilacakPuan, "ceviklik");
                    beceriPuani -= beceriyeAktarilacakPuan;
                    break;
                case 3: // Dayanıklık artırmak
                    NiteligeEkleFunction(&dayaniklilik, beceriyeAktarilacakPuan, "dayaniklilik");
                    beceriPuani -= beceriyeAktarilacakPuan;
                    break;
                case 4: // Karizma artırmak
                    NiteligeEkleFunction(&karizma, beceriyeAktarilacakPuan, "karizma");
                    beceriPuani -= beceriyeAktarilacakPuan;
                    break;
                case 5: // Toplayıcılık artırmak
                    NiteligeEkleFunction(&toplayicilik, beceriyeAktarilacakPuan, "toplayicilik");
                    beceriPuani -= beceriyeAktarilacakPuan;
                    break;
                default:
                    printf("\nGecersiz giris");
                    break;
                }
            }
        }
    }
    MenuFunction(); // Ana menüye dön
}

void NiteligeEkleFunction(int *kotrolEdilecek, int eklenecekMik, char isim[]) // Bir niteliğe belli bir miktar eklemek için kullanılır.
{
    // Eğer bu nitelik karakterin becerilerinden biri ise o nitelik 25'ten fazla çıkmamalı, değilse 100'den fazla çıkmamalı!
    int bulundu = 0;
    char *beceriler[5] = {"guc", "ceviklik", "dayaniklilik", "karizma", "toplayicilik"};
    for (int i = 0; i < 5; i++)
    {
        if (strcmp(isim, beceriler[i]) == 0)
        {
            bulundu = 1; // Buluduysa 1 olur
            break;
        }
    }
    if (bulundu == 0)
    { // Temel nitelik durumunda
        if (*kotrolEdilecek + eklenecekMik > 100)
        {
            *kotrolEdilecek = 100;
            printf("\nYeni %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
        else
        {
            *kotrolEdilecek += eklenecekMik;
            printf("Yeni %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
        if (*kotrolEdilecek <= 10)
        {
            printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("DIKKAT %s degerin 10'un altinda!!!\n");
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
        }
    }
    else
    { // Beceri nitelik durumunda
        if (*kotrolEdilecek + eklenecekMik > 25)
        {
            *kotrolEdilecek = 25;
            printf("\n %s degerini maksimum degerine ulasti!%d\n", isim, *kotrolEdilecek);
        }
        else
        {
            *kotrolEdilecek += eklenecekMik;
            printf("Yeni %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
    }
}

void NiteliktenCikarFunction(int *kotrolEdilecek, int cikacakMik, char isim[]) // Bir niteliğe belli bir miktar çıkarmak için kullanılır.
{
    int bulundu = 0;
    char *beceriler[5] = {"guc", "ceviklik", "dayaniklilik", "karizma", "toplayicilik"};
    for (int i = 0; i < 5; i++)
    {
        if (strcmp(isim, beceriler[i]) == 0)
        {
            bulundu = 1; // Buluduysa 1 olur
            break;
        }
    }
    if (bulundu == 0)
    { // Temel nitelek durumu
        if (*kotrolEdilecek - cikacakMik < 0)
        {
            *kotrolEdilecek = 0;
            printf("\nKalan %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
        else
        {
            *kotrolEdilecek -= cikacakMik;
            printf("Kalan %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
        if (*kotrolEdilecek <= 10)
        { // Temel niteliği 10'un altına düşerse uyarı verir
            printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("DIKKAT %s degerin 10'un altina dustu!!!\n");
            if (*kotrolEdilecek == 0)
            { // Temel niteliği 0'a düşerse uyarı verir ve candan 2 çıkarır
                can -= 2;
                printf("GIDEREK CAN KAYBEDIYORSUN !!!\ncan : %d\n", can);
                if (can == 0)
                { // Ölme durumunda(Can = 0)
                    printf("Hay aksi! Can degerin 0'landi.");
                    printf("\n\nxxxxxxxxxxxxxxxxxxxxxxxxxx\n\tOYUN BITTI\nxxxxxxxxxxxxxxxxxxxxxxxxx\n");
                    exit(0);
                }
            }
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
        }
    }
    else
    {
        if (*kotrolEdilecek - cikacakMik < 0) // Beceri niteliği durumunda
        {
            *kotrolEdilecek = 0;
            printf("\nKalan %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
        else
        {
            *kotrolEdilecek -= cikacakMik;
            printf("Yeni %s seviyen: %d\n", isim, *kotrolEdilecek);
        }
        if (*kotrolEdilecek <= 3)
        { // 3 ten fazla düşerse uyarı verir
            printf("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
            printf("DIKKAT %s degerin 3'e dustu!!!\n", isim);
        }
    }
}

int main()
{
    srand(time(0)); // Burada her saferde rastgele bir sayıyı gelmesini sağlarız.

    // ozan adi ve calgi input
    printf("\n\nDIKKAT!\nOyunumuzda buyuk bir harita mevcuttur, daha iyi bir oyun deneyimi icin konsolunuzu buyutmenizi tavsiye ediyoruz.\nIyi oyunlar dileriz...\n\n");
    printf("Ozanin Adi : ");
    gets(ozan);
    printf("Calginiz : ");
    gets(calgi);

    // Ana menü çağralır... buradan oluşturduğnuz karakter ile oynayabilirsiniz!
    MenuFunction();
}